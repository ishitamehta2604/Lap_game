'''
File: SolutionCode.py
Project: A4_LAP_game_player
File Created: Thursday, 10th October 2019 2:14:27 am
Author: Ishita Mehta
-----
Last Modified: Thursday, 10th October 2019 6:17:36 pm
Modified By: Siyu Ye (andyyesiyu@gmail.com>)
-----
Copyright (c) - 2019 Siyu Ye
'''

from collections import Counter, defaultdict
from itertools import permutations
from random import choice

def print_matrix(data):
    """ Print 2d list nicely
    
    Args:
        data ([[String]]): A 2d list
    """
    print('\n'.join(
        ['\t'.join([str(cell) if cell else '*' for cell in row]) for row in data]))


def copy(x):
    """ Deep copy of 2d list
    
    Args:
        x ([[String]]): A 2d list
    """
    return [row[:] for row in x]


class Solution (object):
    def __init__(self, width: int, height: int, seg_num: int):
        self.width = width
        self.height = height
        self.seg_num = seg_num

        if width * height % seg_num != 0:
            print('invalid input please')
            return
        self.symbol_num = width*height/seg_num
        self.empty_board = [[None for _ in range(self.width)]
                            for _ in range(self.height)] # empty initiate board
        self.possible_answer = [] # all the possible answers based on all the clues we have
        self.ask_ind = 0 # record the position of questions we ask
        self.clue_store = {} # store all the clues got 
        self.box_region = [] # question list 
        self.BoxTraversalCreate() # initiate question list

    def BoxTraversalCreate(self):

        # Create general traversal pattern for all the game, super slow but can work in everyone
        for col in range(0, self.width-2):
            self.box_region.append([(0, col), (0, col+1),
                                    (1, col), (1, col+1)])

        for row in range(0, self.height-2):
            self.box_region.append([(row, self.width-2), (row+1, self.width-1),
                                    (row, self.width-2), (row+1, self.width-1)])
        for col in range(self.width-1, 0, -1):
            self.box_region.append([(self.height-2, col-1), (self.height - 2, col),
                                    (self.height-1, col-1), (self.height-1, col)])
        for row in range(self.height-2, 0, -1):
            self.box_region.append([(row, 0), (row, 1),
                                    (row+1, 0), (row+1, 1)])
        for row, col in zip(range(0, self.width-1), range(0, self.height-1)):
            self.box_region.append([(row, col), (row, col+1),
                                    (row + 1, col), (row + 1, col+1)])
        for row, col in zip(range(0, self.height-1), range(self.width-2, -1, -1)):
            self.box_region.append([(row, col), (row, col + 1),
                                    (row + 1, col), (row + 1, col + 1)])
        self.box_region = [i[0] for i in self.box_region]
        

        # optimized pattern for small puzzles
        if self.height == self.width == 6:
            # Following one can guarantee the correctness but slower
            # self.box_region = [(0, 0), (1, 1), (2, 2), (3, 3), (4, 4), (1, 3),
            #                    (0, 4), (3, 1), (4, 0), (2, 0), (4, 2), (0, 2), (2, 4)]

            # Quicker and with high assurance
            self.box_region = [(0,0),(1,1),(0,2),(1,3),(0,4),(2,0),(3,2),(2,4),(4,0),(4,2),(4,4)]
        elif self.height == self.width == 8:
            self.box_region = [(0,0),(0,2), (0,4),(0,6),(2,0),(1,2),(2,2),(2,4),(2,6),(4,0),(4,2),(4,4),(3,4),(4,6),(6,0),(6,2),(6,4),(6,6),(5,6)]


    def check_complete(self, board):
        """ Check board valid or not. Using dfs to expand each region. Check feasibility based on region numbers.
        
        Args:
            board ([[String]]): A full board
        """
        num = self.width * self.height / self.seg_num
        dfs_time = 0

        check_dic = defaultdict(int)
        self.seen = set()

        def dfs(i, j):
            self.seen.add((i, j))
            surround_ind = [(i-1, j), (i+1, j),
                            (i, j+1), (i, j-1)]
            for surr_row, surr_col in surround_ind:
                if 0 <= surr_row < self.height and 0 <= surr_col < self.width:
                    if (surr_row, surr_col) not in self.seen and board[surr_row][surr_col] == board[i][j]:
                        dfs(surr_row, surr_col)
            return 1

        for rows in range(self.height):
            for cols in range(self.width):
                if (rows, cols) not in self.seen:
                    dfs_time += 1
                    dfs(rows, cols)
                    if dfs_time > self.seg_num:
                        return False
                seg_str = board[rows][cols]

                check_dic[seg_str] += 1
                if check_dic[seg_str] > num: # also check number of elements in a region
                    return False

        return True

    def give_question(self):
        """ Give questions to server
        """
        # check whether receive previous clue
        if not self.clue_store or self.box_region[self.ask_ind - 1] in self.clue_store:
            # If we filled the whole possible board then, guess the result
            if self.possible_answer and all([all(i) for i in self.possible_answer[0]]) and self.ask_ind == len(self.box_region)-1:
                print('full')

                all_possible = []
                for possible in self.possible_answer:
                    if self.check_complete(possible):
                        all_possible.append(possible)
                for n in all_possible:
                    print_matrix(n)
                    print('\n')
                
                # Exclude the possible answer if not correct
                self.possible_answer = all_possible[1:]
                return ["".join(n) for n in all_possible[0]]

            # return Questions
            if self.ask_ind < len(self.box_region):
                # In our question list then fetch from set-up list
                ret = self.box_region[self.ask_ind]
                self.ask_ind += 1
            else:
                # After the whole questions list, random choose from empty cells
                ret = choice([(i,j)for i in range(self.height-1) for j in range(self.width-1)  if (i,j) not in self.clue_store ])
                self.box_region.append(ret)
                self.ask_ind += 1
            return str(ret)
        else:
            return 'Not Receive Previous Clue'

    def receive_clue(self, clue):
        # clue: string with length of 4, xxxy

        clue_pos = self.box_region[self.ask_ind-1] # postion of clues
        self.clue_store[clue_pos] = clue
        
        # Using Counter to count high efficiently. The most_common() function of Counter can return a sorted list based on the number of keys
        count = Counter(clue)

        type_cell = None # 4, 22, 31, 111, and 211 
        if all([count[key] == 4 for key in count]):
            type_cell = '4'
        elif all([count[key] == 2 for key in count]):
            type_cell = '22'
        elif any([count[key] == 3 for key in count]):
            type_cell = '31'
        elif all([count[key] == 1 for key in count]):
            type_cell = '1111'
        else:
            type_cell = '211'

        # fetch all possible board only containing the position of clues. A board with only 4 cells with elements.
        curr_possible_board = self.produce_possible_board(clue_pos,
                                                          type_cell, [i[0] for i in count.most_common()])
        next_possible_answer = []
        # Check feasibility of previous possible boards combining with current board.
        if not self.possible_answer:
            self.possible_answer += curr_possible_board
        else:
            for possible_prev in self.possible_answer:
                for possible_curr in curr_possible_board:
                    check_res = self.check_feasibility(
                        possible_prev, possible_curr)

                    if check_res[0]:
                        next_possible_answer.append(check_res[1])
            self.possible_answer = next_possible_answer

        for ind, i in enumerate(self.possible_answer):
            # Show all the deduction during playing a game
            print(ind)
            print_matrix(i)
            print('\n')
        return

    def produce_possible_board(self, clue_pos, type_cell, keys):
        """ Brute force generate all possible patterns. A super long-winded function but workable
        
        Args:
            clue_pos (tuple): position of clues to handle
            type_cell (String): type of the 4 elements cells, (4, 31, 22, 1111)
            keys ([String]): segment number of the cells
        """
        origion_cor = clue_pos
        right_cor = (clue_pos[0], clue_pos[1]+1)
        down_cor = (clue_pos[0]+1, clue_pos[1])
        right_down_cor = (clue_pos[0]+1, clue_pos[1]+1)
        ret = []
        if type_cell == '22':
            possible1 = copy(self.empty_board)
            possible1[origion_cor[0]][origion_cor[1]] = keys[0]
            possible1[right_cor[0]][right_cor[1]] = keys[0]
            possible1[down_cor[0]][down_cor[1]] = keys[1]
            possible1[right_down_cor[0]][right_down_cor[1]] = keys[1]

            possible2 = copy(self.empty_board)
            possible2[origion_cor[0]][origion_cor[1]] = keys[1]
            possible2[right_cor[0]][right_cor[1]] = keys[1]
            possible2[down_cor[0]][down_cor[1]] = keys[0]
            possible2[right_down_cor[0]][right_down_cor[1]] = keys[0]

            possible3 = copy(self.empty_board)
            possible3[origion_cor[0]][origion_cor[1]] = keys[1]
            possible3[down_cor[0]][down_cor[1]] = keys[1]
            possible3[right_cor[0]][right_cor[1]] = keys[0]
            possible3[right_down_cor[0]][right_down_cor[1]] = keys[0]

            possible4 = copy(self.empty_board)
            possible4[origion_cor[0]][origion_cor[1]] = keys[0]
            possible4[down_cor[0]][down_cor[1]] = keys[0]
            possible4[right_cor[0]][right_cor[1]] = keys[1]
            possible4[right_down_cor[0]][right_down_cor[1]] = keys[1]

            ret = [possible1, possible2, possible3, possible4]
        elif type_cell == '31':
            print('keys', keys)
            possible1 = copy(self.empty_board)
            possible1[origion_cor[0]][origion_cor[1]] = keys[0]
            possible1[right_cor[0]][right_cor[1]] = keys[0]
            possible1[down_cor[0]][down_cor[1]] = keys[0]
            possible1[right_down_cor[0]][right_down_cor[1]] = keys[1]

            possible2 = copy(self.empty_board)
            possible2[origion_cor[0]][origion_cor[1]] = keys[0]
            possible2[right_cor[0]][right_cor[1]] = keys[0]
            possible2[down_cor[0]][down_cor[1]] = keys[1]
            possible2[right_down_cor[0]][right_down_cor[1]] = keys[0]

            possible3 = copy(self.empty_board)
            possible3[origion_cor[0]][origion_cor[1]] = keys[0]
            possible3[right_cor[0]][right_cor[1]] = keys[1]
            possible3[down_cor[0]][down_cor[1]] = keys[0]
            possible3[right_down_cor[0]][right_down_cor[1]] = keys[0]

            possible4 = copy(self.empty_board)
            possible4[origion_cor[0]][origion_cor[1]] = keys[1]
            possible4[right_cor[0]][right_cor[1]] = keys[0]
            possible4[down_cor[0]][down_cor[1]] = keys[0]
            possible4[right_down_cor[0]][right_down_cor[1]] = keys[0]

            ret = [possible1, possible2, possible3, possible4]

        elif type_cell == '1111':
            perm = permutations(keys)
            for combine in perm:
                possibleN = copy(self.empty_board)
                possibleN[origion_cor[0]][origion_cor[1]] = combine[0]
                possibleN[right_cor[0]][right_cor[1]] = combine[1]
                possibleN[down_cor[0]][down_cor[1]] = combine[2]
                possibleN[right_down_cor[0]][right_down_cor[1]] = combine[3]
                ret.append(possibleN)
        elif type_cell == '211':

            # up two down one one
            possible1 = copy(self.empty_board)
            possible1[origion_cor[0]][origion_cor[1]] = keys[0]
            possible1[right_cor[0]][right_cor[1]] = keys[0]
            possible1[down_cor[0]][down_cor[1]] = keys[1]
            possible1[right_down_cor[0]][right_down_cor[1]] = keys[2]

            possible2 = copy(self.empty_board)
            possible2[origion_cor[0]][origion_cor[1]] = keys[0]
            possible2[right_cor[0]][right_cor[1]] = keys[0]
            possible2[down_cor[0]][down_cor[1]] = keys[2]
            possible2[right_down_cor[0]][right_down_cor[1]] = keys[1]

            # left two down one one
            possible3 = copy(self.empty_board)
            possible3[origion_cor[0]][origion_cor[1]] = keys[0]
            possible3[right_cor[0]][right_cor[1]] = keys[2]
            possible3[down_cor[0]][down_cor[1]] = keys[0]
            possible3[right_down_cor[0]][right_down_cor[1]] = keys[1]

            possible4 = copy(self.empty_board)
            possible4[origion_cor[0]][origion_cor[1]] = keys[0]
            possible4[right_cor[0]][right_cor[1]] = keys[1]
            possible4[down_cor[0]][down_cor[1]] = keys[0]
            possible4[right_down_cor[0]][right_down_cor[1]] = keys[2]

            # down two up one one
            possible5 = copy(self.empty_board)
            possible5[origion_cor[0]][origion_cor[1]] = keys[1]
            possible5[right_cor[0]][right_cor[1]] = keys[2]
            possible5[down_cor[0]][down_cor[1]] = keys[0]
            possible5[right_down_cor[0]][right_down_cor[1]] = keys[0]

            possible6 = copy(self.empty_board)
            possible6[origion_cor[0]][origion_cor[1]] = keys[2]
            possible6[right_cor[0]][right_cor[1]] = keys[1]
            possible6[down_cor[0]][down_cor[1]] = keys[0]
            possible6[right_down_cor[0]][right_down_cor[1]] = keys[0]

            # right two left one one
            possible7 = copy(self.empty_board)
            possible7[origion_cor[0]][origion_cor[1]] = keys[1]
            possible7[right_cor[0]][right_cor[1]] = keys[0]
            possible7[down_cor[0]][down_cor[1]] = keys[2]
            possible7[right_down_cor[0]][right_down_cor[1]] = keys[0]

            possible8 = copy(self.empty_board)
            possible8[origion_cor[0]][origion_cor[1]] = keys[2]
            possible8[right_cor[0]][right_cor[1]] = keys[0]
            possible8[down_cor[0]][down_cor[1]] = keys[1]
            possible8[right_down_cor[0]][right_down_cor[1]] = keys[0]

            ret = [possible1, possible2, possible3, possible4,
                   possible5, possible6, possible7, possible8]
        elif type_cell == '4':
            possible = copy(self.empty_board)
            possible[origion_cor[0]][origion_cor[1]] = keys[0]
            possible[right_cor[0]][right_cor[1]] = keys[0]
            possible[down_cor[0]][down_cor[1]] = keys[0]
            possible[right_down_cor[0]][right_down_cor[1]] = keys[0]
            ret = [possible]
        else:
            return 'Not a legal type'
        return ret

    def check_feasibility(self, possible_prev, possible_curr):
        """ Check whether we can combine the possible previous one with current one
        
        Args:
            possible_prev ([[String]]): previous possible solutions
            possible_curr ([[String]]): a board with only 4 elements based on the clue of this stage
        """
        ret = copy(possible_prev)
        for i in range(self.height):
            for j in range(self.width):

                if possible_prev[i][j] and possible_curr[i][j]:
                    if possible_prev[i][j] != possible_curr[i][j]:

                        return False, False
                elif possible_curr[i][j]:
                    ret[i][j] = possible_curr[i][j]

        return True, ret


if __name__ == '__main__':
    # Testing
    solver = Solution(6, 6, 4)
    print(solver.check_complete(
        [
            ['z', 'z', 'z', 'z', 'w', 'w'],
            ['z', 'z', 'y', 'z', 'w', 'w'],
            ['z', 'z', 'y', 'y', 'w', 'w'],
            ['y', 'y', 'y', 'y', 'w', 'w'],
            ['x', 'y', 'y', 'x', 'w', 'x'],
            ['x', 'x', 'x', 'x', 'x', 'x']
        ]
    ))

