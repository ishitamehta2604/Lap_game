# A4_LAP_game_player

Course Number: UIUC IS590PZ
client program to play the LAP game through PZ-server

# Team Members

Siyu Ye: siyuye2
Ishita Mehta: im20

# Files

SolutionCode.py: Solution program for solving the opponent's puzzle
generator.py: Generator of our own puzzles
play_lap.py: Connection program to connect and compete using server
play_rps_testing.py: Testing program for debug

# Basic Ideas

## Generator

Using dfs to generate every region in sequence. For example, for a 6x6 and 4 regions puzzle, first generate all the 'w' region. After finishing all 9 of 'w', go to the 'x', after the 'x' go to 'y', finally, generate all the 'z'.

As the region may become bigger and dfs is hard to handle. There are several optimization strategies in the code. Through all of them, the basic principle is to find the next step with minium possibility, in other word, choose the next step with minium numbers of valid next steps. So for large puzzle the generator may produce relative simple one.

## Solver

The algorithm is based on the logic that finding all the possible ways of putting the elements based on current clue. Than combine the current possible ways to the previous possible boards. During the deduction, there are several possible paths of the answers (sometime really big number of them), but as the deduction, and controlling the overlaps, the number of them will reduce in high speed.

After filling all the areas of the board, we check the contagion of the possible answers and exclude the invalid one. Usually, the possible answers after checking will be in a limited number, say about 1-3, so we can post every of them to the server. (As the rule changing, I will not fail if I guess wrongly)

## Connector

An edited program based on professor's sample code, which imports generator and solver.
