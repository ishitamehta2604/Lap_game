'''
File: generator.py
Project: A4_LAP_game_player
File Created: Friday, 4th October 2019 9:40:15 am
Author: Siyu Ye (andyyesiyu@gmail.com)
-----
Last Modified: Thursday, 10th October 2019 6:18:38 pm
Modified By: Siyu Ye (andyyesiyu@gmail.com>)
-----
Copyright (c) - 2019 Siyu Ye
'''


from random import choice, shuffle
import collections


class Generator(object):
    def __init__(self, width, height, seg_num):
        self.width = width
        self.height = height
        self.seg_num = seg_num
        if width * height % seg_num != 0:
            # handle invalid input
            print('invalid input please')
            return
        self.symbol_num = width*height/seg_num
        self.board = [[None for _ in range(self.width)]
                      for _ in range(self.height)]
        print(self.symbol_num)
        self.symbol = [chr(i) for i in range(97, 97+26)][26-int(seg_num):27]

    def decode_board(self):
        """ Decode 2d Board to [String]

        Returns:
            [String] -- Init Board
        """
        return ["".join(n) for n in self.board]

    def check_complete(self, board):
        """ Check if the self.board is valid in generation 

        Args:
            board ([[String]]): matrix to be testing

        Returns:
            Boolen: True if matrix is valid, False otherwise
        """
        num = self.width * self.height / self.seg_num
        print('cf', board)
        check_dic = {symbol: self.symbol_num for symbol in self.symbol}

        for rows in range(self.height):
            for cols in range(self.width):
                seg_str = board[rows][cols]

                check_dic[seg_str] -= 1
                if check_dic[seg_str] < 0:
                    return False

                surround_ind = [(rows-1, cols), (rows+1, cols),
                                (rows, cols+1), (rows, cols-1)]
                surround_str = []
                for surr_row, surr_col in surround_ind:
                    if 0 <= surr_row < self.height and 0 <= surr_col < self.width:
                        surround_str.append(board[surr_row][surr_col])

                if num > 1:
                    if not any([surr_str == seg_str for surr_str in surround_str]):
                        return False

        return True

    def generate(self, config):
        """ Generate the problem 

        Args:
            config ([int]): config can set complexity. If no config, 
            the generator would do it automatically balancing time and complexity; 
            config -> 1,2,3 (complexity increases as the number being larger)

        Returns:
            None
        """

        if not config:
            complex_num = 1 if self.width < 10 and self.height < 10 else 2
        else:
            complex_num = config

        generate_list = self.symbol[:]
        shuffle(generate_list)
        num = self.width * self.height / self.seg_num

        # using dfs to generate whole puzzle, several optimization to speed up
        def dfs(row, col, curr_fill, curr_fill_num, used_lst):

            self.board[row][col] = curr_fill
            curr_fill_num += 1

            if curr_fill_num == self.width * self.height:
                print('check')
                if self.check_complete(self.board):
                    # print('final', self.board)

                    return True
            next_move = []
            if curr_fill_num % num == 0:
                # create new segment
                nxt_class_lst = [i for i in generate_list if i not in used_lst]
                nxt_class = choice(nxt_class_lst)
                min_nxt_move = []
                for nxt_row in range(self.height):
                    for nxt_col in range(self.width):
                        if self.board[nxt_row][nxt_col] == None:
                            # choose next step with minium next valid steps to accelerate dfs speed
                            nxt_move_num = 0
                            surround_ind = [(nxt_row-1, nxt_col), (nxt_row+1, nxt_col),
                                            (nxt_row, nxt_col+1), (nxt_row, nxt_col-1)]
                            for surr_row, surr_col in surround_ind:
                                if 0 <= surr_row < self.height and 0 <= surr_col < self.width:
                                    if self.board[surr_row][surr_col] == None:
                                        nxt_move_num += 1
                            if not min_nxt_move:
                                min_nxt_move.append(
                                    (nxt_move_num, nxt_row, nxt_col))
                            else:
                                if nxt_move_num < min_nxt_move[0][0]:
                                    min_nxt_move = [(
                                        nxt_move_num, nxt_row, nxt_col)]
                                elif nxt_move_num == min_nxt_move[0][0]:
                                    min_nxt_move.append((
                                        nxt_move_num, nxt_row, nxt_col))

                next_move = [
                    (next_choose[1], next_choose[2], nxt_class,
                     curr_fill_num, used_lst+[nxt_class])
                    for next_choose in min_nxt_move]
                shuffle(next_move)
                # one step is enough, if valid, always valid, vice versa.
                next_move = next_move[:1]
            else:
                # current segment expand
                surround_ind = [(row-1, col), (row+1, col),
                                (row, col+1), (row, col-1)]
                for surr_row, surr_col in surround_ind:
                    if 0 <= surr_row < self.height and 0 <= surr_col < self.width:
                        if self.board[surr_row][surr_col] == None:
                            # scan the next steps' next steps, first handle those with 1 or 0 further step to speed up.
                            nxt_step_count = 0
                            nxt_surround_ind = [(surr_row-1, surr_col), (surr_row+1, surr_col),
                                                (surr_row, surr_col+1), (surr_row, surr_col-1)]
                            for nxt_surr_row, nxt_surr_col in nxt_surround_ind:
                                if 0 <= nxt_surr_row < self.height and 0 <= nxt_surr_col < self.width and (nxt_surr_row, nxt_surr_col) != (surr_row, surr_col):
                                    if self.board[nxt_surr_row][nxt_surr_col] == None:
                                        nxt_step_count += 1
                            next_move.append(
                                (nxt_step_count, surr_row, surr_col))

                prev_next_move = sorted([(ele[1], ele[2], curr_fill, curr_fill_num, used_lst)
                                         for ele in next_move if ele[0] <= complex_num])
                lose_next_move = [(ele[1], ele[2], curr_fill, curr_fill_num, used_lst)
                                  for ele in next_move if ele[0] > complex_num]

                shuffle(lose_next_move)
                next_move = lose_next_move + prev_next_move[::-1]
                # reverse to let smaller one on tail position, and we can use pop to fetch smaller one first

            while next_move:
                res = dfs(*next_move.pop())
                if res:
                    return True

            if not next_move:
                self.board[row][col] = None

                return False

        first_seg = choice(generate_list)
        dfs(0, 0, first_seg, 0, [first_seg])

    def post_puzzle(self):
        """ Generate the puzzle and send decode json back to server

        Returns:
            [[str]]
        """
        self.generate([])
        return(self.decode_board())


if __name__ == "__main__":

    # For testing
    solve = Generator(6, 6, 4)
    solve.generate([])
    print(solve.decode_board())
